#!/bin/bash

# 报表生成系统 Linux 部署脚本
# 此脚本将系统部署到 /opt/report-system 并设置开机自启服务

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 配置变量
APP_NAME="report-system"
INSTALL_DIR="/opt/${APP_NAME}"
SERVICE_NAME="${APP_NAME}.service"
PORT=45555
CURRENT_USER="${SUDO_USER:-$USER}"
CURRENT_USER_HOME=$(eval echo ~${CURRENT_USER})

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  报表生成系统 Linux 部署脚本${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""

# 检查是否以root权限运行
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}错误: 请使用 sudo 运行此脚本${NC}"
    echo "使用方法: sudo bash install.sh"
    exit 1
fi

# 检查Python是否安装
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}错误: 未找到 python3，请先安装 Python 3${NC}"
    exit 1
fi

echo -e "${YELLOW}[1/6] 检查系统环境...${NC}"
echo "  - 当前用户: ${CURRENT_USER}"
echo "  - 用户主目录: ${CURRENT_USER_HOME}"
echo "  - Python 版本: $(python3 --version)"
echo "  - 安装目录: ${INSTALL_DIR}"
echo "  - 服务端口: ${PORT}"
echo ""

# 创建安装目录
echo -e "${YELLOW}[2/6] 创建安装目录并复制文件...${NC}"
mkdir -p "${INSTALL_DIR}"

# 获取脚本所在目录（源目录）
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "  从 ${SCRIPT_DIR} 复制文件到 ${INSTALL_DIR}"

# 复制所有文件到安装目录（包括脚本本身、说明文档等）
cp -r "${SCRIPT_DIR}"/* "${INSTALL_DIR}/"

# 特别确保关键文件已复制
if [ -f "${SCRIPT_DIR}/uninstall.sh" ]; then
    cp "${SCRIPT_DIR}/uninstall.sh" "${INSTALL_DIR}/"
fi
if [ -f "${SCRIPT_DIR}/README.md" ]; then
    cp "${SCRIPT_DIR}/README.md" "${INSTALL_DIR}/"
fi

# 设置正确的权限
chown -R root:root "${INSTALL_DIR}"
chmod -R 755 "${INSTALL_DIR}"
find "${INSTALL_DIR}" -type f -exec chmod 644 {} \;
# 确保脚本文件可执行
chmod 755 "${INSTALL_DIR}/install.sh" 2>/dev/null || true
chmod 755 "${INSTALL_DIR}/uninstall.sh" 2>/dev/null || true

echo -e "${GREEN}  ✓ 文件复制完成（包含脚本和说明文档）${NC}"
echo ""

# 创建systemd服务文件
echo -e "${YELLOW}[3/6] 创建 systemd 服务...${NC}"
cat > /etc/systemd/system/${SERVICE_NAME} <<EOF
[Unit]
Description=Report System Web Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=${INSTALL_DIR}
ExecStart=/usr/bin/python3 -m http.server ${PORT}
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

echo -e "${GREEN}  ✓ 服务文件已创建: /etc/systemd/system/${SERVICE_NAME}${NC}"
echo ""

# 重载systemd并启用服务
echo -e "${YELLOW}[4/6] 启用并启动服务...${NC}"
systemctl daemon-reload
systemctl enable ${SERVICE_NAME}
systemctl start ${SERVICE_NAME}

# 检查服务状态
if systemctl is-active --quiet ${SERVICE_NAME}; then
    echo -e "${GREEN}  ✓ 服务已成功启动${NC}"
else
    echo -e "${RED}  ✗ 服务启动失败，请检查日志: journalctl -u ${SERVICE_NAME}${NC}"
    exit 1
fi
echo ""

# 创建桌面快捷方式
echo -e "${YELLOW}[5/6] 创建桌面快捷方式...${NC}"

# 尝试多个可能的桌面目录
DESKTOP_DIRS=(
    "${CURRENT_USER_HOME}/Desktop"
    "${CURRENT_USER_HOME}/桌面"
    "${CURRENT_USER_HOME}/desktop"
)

DESKTOP_DIR=""
for dir in "${DESKTOP_DIRS[@]}"; do
    if [ -d "$dir" ]; then
        DESKTOP_DIR="$dir"
        break
    fi
done

if [ -z "$DESKTOP_DIR" ]; then
    # 如果都不存在，创建Desktop目录
    DESKTOP_DIR="${CURRENT_USER_HOME}/Desktop"
    mkdir -p "$DESKTOP_DIR"
    chown ${CURRENT_USER}:${CURRENT_USER} "$DESKTOP_DIR"
    echo "  创建桌面目录: $DESKTOP_DIR"
fi

# 创建桌面快捷方式文件
DESKTOP_FILE="${DESKTOP_DIR}/report-system.desktop"
cat > "${DESKTOP_FILE}" <<EOF
[Desktop Entry]
Version=1.0
Type=Application
Name=报表生成系统
Comment=粮食报表生成系统
Exec=xdg-open http://localhost:${PORT}
Icon=${INSTALL_DIR}/icon.png
Terminal=false
Categories=Application;Network;
StartupNotify=true
EOF

# 设置桌面文件权限和所有者
chown ${CURRENT_USER}:${CURRENT_USER} "${DESKTOP_FILE}"
chmod 755 "${DESKTOP_FILE}"

# 如果是可执行的桌面文件，标记为可信任（针对某些桌面环境）
if command -v gio &> /dev/null; then
    sudo -u ${CURRENT_USER} gio set "${DESKTOP_FILE}" metadata::trusted true 2>/dev/null || true
fi

echo -e "${GREEN}  ✓ 桌面快捷方式已创建: ${DESKTOP_FILE}${NC}"
echo ""

# 显示防火墙提示
echo -e "${YELLOW}[6/6] 配置防火墙...${NC}"
echo "  正在尝试开放端口 ${PORT}..."

# 尝试配置firewalld（RHEL/CentOS/Fedora）
if command -v firewall-cmd &> /dev/null; then
    if systemctl is-active --quiet firewalld; then
        firewall-cmd --permanent --add-port=${PORT}/tcp 2>/dev/null || true
        firewall-cmd --reload 2>/dev/null || true
        echo -e "${GREEN}  ✓ firewalld 已配置${NC}"
    fi
fi

# 尝试配置ufw（Ubuntu/Debian）
if command -v ufw &> /dev/null; then
    if ufw status | grep -q "Status: active"; then
        ufw allow ${PORT}/tcp 2>/dev/null || true
        echo -e "${GREEN}  ✓ ufw 已配置${NC}"
    fi
fi

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  安装完成！${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo "系统信息："
echo "  - 安装目录: ${INSTALL_DIR}"
echo "  - 服务名称: ${SERVICE_NAME}"
echo "  - 访问地址: http://localhost:${PORT}"
echo "  - 桌面快捷方式: ${DESKTOP_FILE}"
echo ""
echo "重要提示："
echo "  - 卸载脚本已复制到: ${INSTALL_DIR}/uninstall.sh"
echo "  - 使用说明已复制到: ${INSTALL_DIR}/README.md"
echo "  - 如需卸载，请运行: sudo bash ${INSTALL_DIR}/uninstall.sh"
echo ""
echo "常用命令："
echo "  - 查看服务状态: sudo systemctl status ${SERVICE_NAME}"
echo "  - 停止服务: sudo systemctl stop ${SERVICE_NAME}"
echo "  - 启动服务: sudo systemctl start ${SERVICE_NAME}"
echo "  - 重启服务: sudo systemctl restart ${SERVICE_NAME}"
echo "  - 查看日志: sudo journalctl -u ${SERVICE_NAME} -f"
echo ""
echo -e "${GREEN}现在可以双击桌面图标启动应用，或在浏览器中访问 http://localhost:${PORT}${NC}"
echo ""

