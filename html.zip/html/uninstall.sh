#!/bin/bash

# 报表生成系统 Linux 卸载脚本
# 此脚本可从任意位置运行（已复制到安装目录）

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# 配置变量
APP_NAME="report-system"
INSTALL_DIR="/opt/${APP_NAME}"
SERVICE_NAME="${APP_NAME}.service"
PORT=45555
CURRENT_USER="${SUDO_USER:-$USER}"
CURRENT_USER_HOME=$(eval echo ~${CURRENT_USER})

echo -e "${RED}========================================${NC}"
echo -e "${RED}  报表生成系统 卸载脚本${NC}"
echo -e "${RED}========================================${NC}"
echo ""

# 检查是否以root权限运行
if [ "$EUID" -ne 0 ]; then 
    echo -e "${RED}错误: 请使用 sudo 运行此脚本${NC}"
    echo "使用方法: sudo bash uninstall.sh"
    echo "或: sudo bash ${INSTALL_DIR}/uninstall.sh"
    exit 1
fi

echo -e "${YELLOW}即将卸载报表生成系统...${NC}"
echo ""
read -p "确认卸载? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "卸载已取消"
    exit 0
fi

echo ""
echo -e "${YELLOW}[1/5] 停止服务...${NC}"
if systemctl is-active --quiet ${SERVICE_NAME}; then
    systemctl stop ${SERVICE_NAME}
    echo -e "${GREEN}  ✓ 服务已停止${NC}"
else
    echo "  服务未运行"
fi
echo ""

echo -e "${YELLOW}[2/5] 禁用服务...${NC}"
if systemctl is-enabled --quiet ${SERVICE_NAME} 2>/dev/null; then
    systemctl disable ${SERVICE_NAME}
    echo -e "${GREEN}  ✓ 服务已禁用${NC}"
else
    echo "  服务未启用"
fi
echo ""

echo -e "${YELLOW}[3/5] 删除服务文件...${NC}"
if [ -f "/etc/systemd/system/${SERVICE_NAME}" ]; then
    rm -f "/etc/systemd/system/${SERVICE_NAME}"
    systemctl daemon-reload
    echo -e "${GREEN}  ✓ 服务文件已删除${NC}"
else
    echo "  服务文件不存在"
fi
echo ""

echo -e "${YELLOW}[4/5] 删除安装目录...${NC}"
if [ -d "${INSTALL_DIR}" ]; then
    rm -rf "${INSTALL_DIR}"
    echo -e "${GREEN}  ✓ 安装目录已删除: ${INSTALL_DIR}${NC}"
else
    echo "  安装目录不存在"
fi
echo ""

echo -e "${YELLOW}[5/5] 删除桌面快捷方式...${NC}"
# 尝试多个可能的桌面目录
DESKTOP_DIRS=(
    "${CURRENT_USER_HOME}/Desktop"
    "${CURRENT_USER_HOME}/桌面"
    "${CURRENT_USER_HOME}/desktop"
)

REMOVED=false
for dir in "${DESKTOP_DIRS[@]}"; do
    DESKTOP_FILE="${dir}/report-system.desktop"
    if [ -f "$DESKTOP_FILE" ]; then
        rm -f "$DESKTOP_FILE"
        echo -e "${GREEN}  ✓ 桌面快捷方式已删除: ${DESKTOP_FILE}${NC}"
        REMOVED=true
    fi
done

if [ "$REMOVED" = false ]; then
    echo "  桌面快捷方式不存在"
fi
echo ""

# 清理防火墙规则（可选）
echo -e "${YELLOW}是否删除防火墙规则? (y/N): ${NC}"
read -p "" -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    # 尝试清理firewalld规则
    if command -v firewall-cmd &> /dev/null; then
        if systemctl is-active --quiet firewalld; then
            firewall-cmd --permanent --remove-port=${PORT}/tcp 2>/dev/null || true
            firewall-cmd --reload 2>/dev/null || true
            echo -e "${GREEN}  ✓ firewalld 规则已删除${NC}"
        fi
    fi
    
    # 尝试清理ufw规则
    if command -v ufw &> /dev/null; then
        if ufw status | grep -q "Status: active"; then
            ufw delete allow ${PORT}/tcp 2>/dev/null || true
            echo -e "${GREEN}  ✓ ufw 规则已删除${NC}"
        fi
    fi
fi

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  卸载完成！${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo "所有组件已成功卸载。"
echo ""

